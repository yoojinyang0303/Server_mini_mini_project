package com.oopsw.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class JoinUserDAO {
	private DataSource dataSource;
	public JoinUserDAO(){
		System.out.println("JoinUserDAO() 생성자");
		try {
			Context context = new InitialContext();
			dataSource = 
					(DataSource) context.lookup("java:comp/env/jdbc/myoracle");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 아이디 중복 체크
	public int checkDuplicateId(String id) {
		int idChk = 0;
		String check = null;
		String sql = "select customer_id from customer where customer_id=?";
		
		try {
			Connection conn = dataSource.getConnection();
			System.out.println("conn: " + conn);
			PreparedStatement pstmt = conn.prepareStatement(sql);
			System.out.println(">> pstmt: " + pstmt);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()) {
				check = rs.getString(1);
				if(check != null) {
					idChk = 1;
				} else {
					idChk = 0;
				}
			}
			System.out.println(">> idChk: " + idChk);		
			
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return idChk;
	}
	
	
	// 일반 고객 회원가입
	public boolean setUser(String id, String pw, String address) {
		boolean result = false;
		String idChk = null;
		String sql = "insert into customer "
				+ "values (?, ?, '1', ?, 'n')";
		String sql2 = "select customer_id from customer where customer_id=?";
		
		try {
			Connection conn = dataSource.getConnection();
			System.out.println("conn: " + conn);
			PreparedStatement pstmt = conn.prepareStatement(sql);
			PreparedStatement pstmt2 = conn.prepareStatement(sql2);
			System.out.println(">> pstmt: " + pstmt);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, address);
			pstmt2.setString(1, id);
			ResultSet rs = pstmt2.executeQuery();
			
			/*if(rs.next()) {
				idChk = rs.getString(1);
			}
			System.out.println(">> idChk: " + idChk);		*/	
			
			/*if(idChk == null && pstmt.executeUpdate() >= 1) {
				result = true;
			} else {
				result = false;
			}*/
			
			
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	// 가게 회원가입
	public boolean setUser(String id, String pw, String restaurantName, String address, String businessNumber) {
		boolean result = false;
		String sql = "insert into restaurant (restaurant_id, password, name, user_type, business_number, address) "
				+ "values(?, ?, ?, '2', ?, ?)";
		
		try {
			Connection conn = dataSource.getConnection();
			System.out.println("conn");
			PreparedStatement pstmt = conn.prepareStatement(sql);
			System.out.println(">> pstmt: " + pstmt);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, restaurantName);
			pstmt.setString(5, address);
			pstmt.setString(4, businessNumber);
			
			if(pstmt.executeUpdate() >= 1) {
				result = true;
			}
			
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
		
	// 라이더 회원가입 - 운전면허O
	public boolean setUser(String id, String pw, String deliveryType, String deliveryLicense) {
		boolean result = false;
		String sql = "insert into rider (user_type, rider_id, password, delivery_type, delivery_license) "
				+ "values('3', ?, ?, ?, ?)";
		
		try {
			Connection conn = dataSource.getConnection();
			System.out.println("conn");
			PreparedStatement pstmt = conn.prepareStatement(sql);
			System.out.println(">> pstmt: " + pstmt);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			pstmt.setString(3, deliveryType);
			pstmt.setString(4, deliveryLicense);
			
			if(pstmt.executeUpdate() >= 1) {
				result = true;
			}
			
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}
}
