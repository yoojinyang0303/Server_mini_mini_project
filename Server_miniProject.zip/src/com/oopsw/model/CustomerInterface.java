package com.oopsw.model;
/*import java.util.ArrayList;

interface CustomerInterface {
	CustomerVO login(String customerId, String password);
	CustomerVO login(String customerId);
	boolean setCustomer(String customerId, String password, char userType,
			String address, char socialAccount);
	ArrayList searchRestaurantOrMenu(String searchWord);
	void printMenuList(int index);
	boolean setOrder(int menuId, String restaurantId, int servings);
	void printOrderHistory(String customerId);
	boolean setCustomerAddress(String customerId, String address);
}*/


import java.util.ArrayList;
import java.util.HashMap;

public interface CustomerInterface {
	/*CustomerVO login(String customerId);
	CustomerVO login(String customerId, String password);
	boolean setCustomer(String customerId, String password, String address);
	boolean setCustomer(String customerId, String address);*/
	// ArrayList searchRestaurantOrMenu(String searchWord);
	HashMap searchRestaurantOrMenu(String searchWord);
	// ArrayList printMenuList(ArrayList list, int index);
	ArrayList printMenuList(String restaurantName);
	// boolean setOrder(String customerId, ArrayList list, int index, String restaurantId, int servings);
	boolean setOrderStatus(String customerId);
	boolean setOrder(String customerId, String orderMenu, String restaurantId, int servings);
	// void printOrderHistory(String customerId);
	ArrayList printOrderHistory(String customerId);
	boolean setCustomerAddress(String customerId, String address);
}
