package com.oopsw.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class LoginDAO {
	private DataSource dataSource;
	public LoginDAO(){
		try {
			Context context = new InitialContext();
			dataSource = 
					(DataSource) context.lookup("java:comp/env/jdbc/myoracle");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
/*	// 고객-소셜 계정 로그인
	public char login(String id) {
		System.out.println("고객 소셜 login() 메서드 실행");
		System.out.println("login(id): " + id);
		String sql = "select user_type from customer where customer_id = ? and social_account = 'y';";
		char userType = 0;
		
		try {
			Connection conn = dataSource.getConnection();
			System.out.println("conn");
			PreparedStatement pstmt = conn.prepareStatement(sql);
			System.out.println(">> pstmt: " + pstmt);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			System.out.println(">> rs: " + rs);
			if(rs.next()) {
				userType = rs.getString(1).charAt(0);
				System.out.println("rs1.next() userType: " + userType);
			}
			System.out.println("--> userType: " + userType);
			rs.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return userType;
	}*/
	
	// 일반 회원 로그인
	public char login(String id, String pw) {
		System.out.println("login() 메서드 실행");
		System.out.println("login(id): " + id);
		System.out.println("login(pw): " + pw);
		String sql1 = "select user_type from customer where customer_id = ? and password = ?";		
		String sql2 = "select user_type from restaurant where restaurant_id = ? and password = ?";
		String sql3 = "select user_type from rider where rider_id = ? and password = ?";
		String sql4 = "select user_type from customer where customer_id = ? and social_account = 'y' and password is null";
		char userType = 0;
		
		try {
			Connection conn = dataSource.getConnection();
			System.out.println("conn");
			PreparedStatement pstmt1 = conn.prepareStatement(sql1);
			PreparedStatement pstmt2 = conn.prepareStatement(sql2);
			PreparedStatement pstmt3 = conn.prepareStatement(sql3);
			PreparedStatement pstmt4 = conn.prepareStatement(sql4);
			System.out.println(">> pstmt1: " + pstmt1);
			System.out.println(">> pstmt2: " + pstmt2);
			System.out.println(">> pstmt3: " + pstmt3);
			System.out.println(">> pstmt4: " + pstmt4);
			pstmt1.setString(1, id);
			pstmt1.setString(2, pw);
			pstmt2.setString(1, id);
			pstmt2.setString(2, pw);
			pstmt3.setString(1, id);
			pstmt3.setString(2, pw);
			pstmt4.setString(1, id);
			ResultSet rs1 = pstmt1.executeQuery();
			ResultSet rs2 = pstmt2.executeQuery();
			ResultSet rs3 = pstmt3.executeQuery();
			ResultSet rs4 = pstmt4.executeQuery();
			System.out.println(">> rs1: " + rs1);
			System.out.println(">> rs2: " + rs2);
			System.out.println(">> rs3: " + rs3);
			System.out.println(">> rs4: " + rs4);
			if(rs1.next()) {
				userType = rs1.getString(1).charAt(0);
				System.out.println("rs1.next() userType: " + userType);
			} else if(rs2.next()) {
				userType = rs2.getString(1).charAt(0);
				System.out.println("rs2.next() userType: " + userType);
			} else if(rs3.next()) {
				userType = rs3.getString(1).charAt(0);
				System.out.println("rs3.next() userType: " + userType);
			} else if(rs4.next()) {
				userType = rs4.getString(1).charAt(0);
				System.out.println("rs4.next() userType: " + userType);
			}
			System.out.println("--> userType: " + userType);
			rs1.close();
			rs2.close();
			rs3.close();
			rs4.close();
			pstmt1.close();
			pstmt2.close();
			pstmt3.close();
			pstmt4.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return userType;
	}
}