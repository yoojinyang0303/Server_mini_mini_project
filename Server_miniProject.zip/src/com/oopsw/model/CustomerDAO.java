package com.oopsw.model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CustomerDAO implements CustomerInterface{
	// private Connection conn;
	private DataSource dataSource;
	
	public CustomerDAO() throws ClassNotFoundException, SQLException {
		try {
			Context context = new InitialContext();
			dataSource = 
					(DataSource) context.lookup("java:comp/env/jdbc/myoracle");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	//�Ҽ� �� �α���
/*	@Override
	public CustomerVO login(String customerId) { 
		String sql = "select user_type, address, social_account from customer where customer_id = ? and social_account = 'y'";
		CustomerVO customer = null;
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customerId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				customer = new CustomerVO(customerId, rs.getString(1).charAt(0), 
						rs.getString(2), rs.getString(3).charAt(0));
				System.out.println("�α��� ����!");
			} else if(rs.next() == false) {
				System.out.println("�α��� ���� :: ���̵� �Ǵ� ��й�ȣ�� �ٽ� Ȯ�����ּ���.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}*/

	//�Ϲ� �� �α���
	/*@Override
	public CustomerVO login(String customerId, String password) { 
		String sql = "select user_type, address, social_account from customer where customer_id = ? and password = ?";
		CustomerVO customer = null;
		
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customerId);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()){
				customer = new CustomerVO(customerId, password, rs.getString(1).charAt(0), 
						rs.getString(2), rs.getString(3).charAt(0));
				System.out.println("�α��� ����!");
			} else if(rs.next() == false) {
				System.out.println("�α��� ���� :: ���̵� �Ǵ� ��й�ȣ�� �ٽ� Ȯ�����ּ���.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}*/

	//�Ϲ� �� ȸ������
	/*@Override
	public boolean setCustomer(String customerId, String password, String address) {
		String sql = "insert into customer (customer_id, password, user_type, address, social_account) values (?, ?, '1', ?, 'n')";
		boolean result = false;
		
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customerId);
			pstmt.setString(2, password);
			pstmt.setString(3, address);
			
			if(pstmt.executeUpdate() >= 1){
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}*/

	//�Ҽ� �� ȸ������
	/*@Override
	public boolean setCustomer(String customerId, String address) {
		String sql = "insert into customer (customer_id, password, user_type, address, social_account) values (?, null, '1', ?, 'y')";
		boolean result = false;
		
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customerId);
			pstmt.setString(2, address);
			
			if(pstmt.executeUpdate() >= 1){
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}*/
	
	@Override
	public HashMap searchRestaurantOrMenu(String searchWord) {
			String sql = "select res.restaurant_id, res.name, m.name " 
					+ "from menu m, restaurant res "
					+ "where res.restaurant_id = m.restaurant_id and "
					+ "(m.category like '%'||?||'%' or res.name like '%'||?||'%' or m.name like '%'||?||'%') and "
					+ "(m.discontinued is null or m.discontinued = 'n')";
			
			String sql2 = "select res.restaurant_id, res.name "
					+ "from menu m, restaurant res "
					+ "where res.restaurant_id = m.restaurant_id "
					+ "and (m.category like '%'||?||'%' or res.name like '%'||?||'%' or m.name like '%'||?||'%') "
					+ "and (m.discontinued is null or m.discontinued = 'n') "
					+ "group by res.restaurant_id, res.name";
		// ArrayList list = new ArrayList();
			HashMap<String, String> resultMap = new HashMap<String, String>();
		
		try {
			System.out.println("DAO - searchWord: " + searchWord);
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			PreparedStatement pstmt2 = conn.prepareStatement(sql2);
			pstmt.setString(1, searchWord);
			pstmt.setString(2, searchWord);
			pstmt.setString(3, searchWord);
			pstmt2.setString(1, searchWord);
			pstmt2.setString(2, searchWord);
			pstmt2.setString(3, searchWord);
			System.out.println("pstmt 파일들 생성 완료");
			
			ResultSet rs = pstmt.executeQuery();
			ResultSet rs2 = pstmt2.executeQuery();
			/*while(rs.next()){
				System.out.println("���Ը�: " + rs.getString(2) + "�޴���: " + rs.getString(3));
			}*/
			
			while(rs2.next()){
				// list.add(rs2.getString(1));
				resultMap.put(rs2.getString(1), rs2.getString(2));
			}
			System.out.println("rs 파일들 생성 완료");
			
			for(int i = 0; i < resultMap.size(); i++) {
				// System.out.println("DAO-list: " + list.get(i));
				System.out.println("DAO - resultMap: " + resultMap.get(i));
			}
			
			rs2.close();
			rs.close();
			pstmt2.close();
			pstmt.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/*@Override
	public ArrayList searchRestaurantOrMenu(String searchWord) {
			String sql = "select res.restaurant_id, res.name, m.name " 
					+ "from menu m, restaurant res "
					+ "where res.restaurant_id = m.restaurant_id and "
					+ "(m.category like '%'||?||'%' or res.name like '%'||?||'%' or m.name like '%'||?||'%') and "
					+ "(m.discontinued is null or m.discontinued = 'n')";
			
			String sql2 = "select res.name "
					+ "from menu m, restaurant res "
					+ "where res.restaurant_id = m.restaurant_id "
					+ "and (m.category like '%'||?||'%' or res.name like '%'||?||'%' or m.name like '%'||?||'%') "
					+ "and (m.discontinued is null or m.discontinued = 'n') "
					+ "group by res.name";
		ArrayList list = new ArrayList();
		
		try {
			System.out.println("DAO - searchWord: " + searchWord);
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			PreparedStatement pstmt2 = conn.prepareStatement(sql2);
			pstmt.setString(1, searchWord);
			pstmt.setString(2, searchWord);
			pstmt.setString(3, searchWord);
			pstmt2.setString(1, searchWord);
			pstmt2.setString(2, searchWord);
			pstmt2.setString(3, searchWord);
			
			ResultSet rs = pstmt.executeQuery();
			ResultSet rs2 = pstmt2.executeQuery();
			while(rs.next()){
				System.out.println("���Ը�: " + rs.getString(2) + "�޴���: " + rs.getString(3));
			}
			
			while(rs2.next()){
				list.add(rs2.getString(1));
			}
			
			for(int i = 0; i < list.size(); i++) {
				System.out.println("DAO-list: " + list.get(i));
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}*/

	@Override
	public ArrayList printMenuList(String restaurantId) {
		String sql = "select name"
				+ " from restaurant"
				+ " where restaurant_id = ?";
		String sql2 = "select m.menu_id, m.name, m.price"
				+ " from restaurant res, menu m"
				+ " where res.restaurant_id = ? and m.restaurant_id = ?"
				+ " and (m.discontinued is null or m.discontinued = 'n')";
		// ArrayList menu2 = new ArrayList();
		ArrayList<MenuItemVO> menu2 = new ArrayList<MenuItemVO>();
		ArrayList menu = new ArrayList();
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			PreparedStatement pstmt2 = conn.prepareStatement(sql2);
			// pstmt.setString(1, (String)list.get(index - 1));
			pstmt2.setString(1, restaurantId);
			pstmt2.setString(2, restaurantId);
			ResultSet rs2 = pstmt2.executeQuery();
			
			int count = 0;
			while(rs2.next()){
				menu.add(rs2.getString(2));
				MenuItemVO vo = new MenuItemVO(rs2.getString(1), rs2.getString(2), rs2.getString(3));
				// menu2.add(menuItem);
				menu2.add(vo);
			}
			System.out.println(">> DAO - menu.size(): " + menu.size());
			System.out.println(">> DAO - menu2.size(): " + menu2.size());
			for(int i = 0; i < menu2.size(); i++) {
				System.out.println("--- menu2["+i+"]");
				System.out.println(menu2.get(i).getMenuId());
				System.out.println(menu2.get(i).getMenuName());
				System.out.println(menu2.get(i).getMenuPrice());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// return menu;
		return menu2;
	}
	
	@Override
	public boolean setOrderStatus(String customerId) {
		boolean result = false;
		String sql = "insert into orderstatus"
				+ " values(order_status_id.nextval, null, null, null, ?, null)";
		
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customerId);
			if(pstmt.executeUpdate() >= 1){
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean setOrder(String customerId, String orderMenu, String restaurantId, int servings) {
		// orderinfo __ order_status_id, menu_id, restaurant_id, servings, price, date
		String sql1 = "select menu_id from menu where name=?";
		String sql2 = "insert into orderinfo"
				+ " values((select max(order_status_id) from orderstatus where customer_id = ?),"
				+ " ?, ?, ?, (select price from menu where menu_id = ?) * ?, sysdate)";
		boolean result = false;
		try {
			// orderList 의 크기만큼 setString 해서 데이터 추가해주어야함.
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt1 = conn.prepareStatement(sql1);
			pstmt1.setString(1, orderMenu);
			ResultSet rs = pstmt1.executeQuery();
			int menuId = 0;
			while(rs.next()){
				menuId = rs.getInt(1);
			}
			
			PreparedStatement pstmt2 = conn.prepareStatement(sql2);
			pstmt2.setString(1, customerId);
			pstmt2.setInt(2, menuId);
			pstmt2.setString(3, restaurantId);
			pstmt2.setInt(4, servings);
			pstmt2.setInt(5, menuId);
			pstmt2.setInt(6, servings);
			if(pstmt2.executeUpdate() >= 1){
				result = true;
			}
			
			pstmt2.close();
			rs.close();
			pstmt1.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public ArrayList printOrderHistory(String customerId) {
		/*String sql = "select res.name, m.name, oi.servings " +
				"from restaurant res, orderstatus os, orderinfo oi, menu m " +
				"where (os.customer_id = ?) and (oi.order_status_id=os.order_status_id) " +
				"and (m.menu_id = oi.menu_id) and (res.restaurant_id = m.restaurant_id)";*/
		
		String sql = "select res.name, m.name, oi.servings, oi.order_status_id, oi.order_date, os.delivery_done " +
				"from restaurant res, orderstatus os, orderinfo oi, menu m " +
				"where (os.customer_id = ?) and (oi.order_status_id=os.order_status_id) " +
				"and (m.menu_id = oi.menu_id) and (res.restaurant_id = m.restaurant_id) and(os.delivery_done = 'y') "
				+ "order by oi.order_status_id";
		
		// 주문합계 구하는 sql문
		/*String sql2 = "select oi.order_status_id, sum(oi.price) "
				+ "from orderinfo oi group by oi.order_status_id";*/
		String sql2 = "select oi.order_status_id, sum(oi.price) from orderinfo oi, orderstatus os "
				+ "where os.delivery_done = 'y' and os.order_status_id=oi.order_status_id and os.customer_id=? "
				+ "group by oi.order_status_id";
		
		ArrayList<OrderHistoryVO> tmpList = new ArrayList<OrderHistoryVO>();
		ArrayList<OrderHistoryVO> orderHistoryList = new ArrayList<OrderHistoryVO>();
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customerId);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				OrderHistoryVO vo = new OrderHistoryVO(rs.getString(1), rs.getString(2), Integer.parseInt(rs.getString(3)), rs.getInt(4), rs.getDate(5), rs.getString(6));
				tmpList.add(vo);
			}
			System.out.println(">>>>> tmpList크기: " + tmpList.size());
			
			// 주문합계 구하는 sql문 (sql2, pstmt2, rs2)
			// PreparedStatement pstmt2 = conn.prepareStatement("select oi.order_status_id, sum(oi.price) from orderinfo oi group by oi.order_status_id");
			PreparedStatement pstmt2 = conn.prepareStatement(sql2);
			pstmt2.setString(1, customerId);
			ResultSet rs2 = pstmt2.executeQuery();
			// ResultSet rs2 = stmt.executeQuery(sql2);
			HashMap<Integer, Integer> totalPriceList = new HashMap<Integer, Integer>();
			while(rs2.next()) {
				totalPriceList.put(rs2.getInt(1), rs2.getInt(2));
			}
			System.out.println(">>>> totalPriceList 크기: " + totalPriceList.size());
			
			ArrayList<String> tmpMenuList = new ArrayList<String>();
						
			int tmpOSId = 0;
			int totalPrice = 0;
			for(int i=0; i<tmpList.size(); i++) {
				System.out.println("\n>> [i]: " + i);
				tmpOSId = tmpList.get(i).getOrderedStatusId();
				if(i==0) {
					tmpMenuList.add(tmpList.get(i).getOrderedMenu());
				} else if(tmpOSId == tmpList.get(i-1).getOrderedStatusId()) {
					tmpMenuList.add(tmpList.get(i).getOrderedMenu());
					for(int k=0; k<tmpMenuList.size(); k++) {
						System.out.println("---> tmpMenuList 메뉴: " + tmpMenuList.get(k));
					}
				} else if(tmpOSId != tmpList.get(i-1).getOrderedStatusId()) {
					int sumPrice = 0;
					for(Map.Entry<Integer, Integer> item : totalPriceList.entrySet()) {
						if(item.getKey() == tmpList.get(i-1).getOrderedStatusId()) {
							sumPrice = item.getValue();
						}
					}
					ArrayList<String> cloneMenu = new ArrayList<String>();
					cloneMenu.addAll(tmpMenuList);
					OrderHistoryVO vo = new OrderHistoryVO(tmpList.get(i-1).getOrderedResName(), cloneMenu, tmpList.get(i-1).getOrderedDate(), sumPrice);
					orderHistoryList.add(vo);
					for(int k=0; k<tmpMenuList.size(); k++) {
						System.out.println("---> tmpMenuList 메뉴: " + cloneMenu.get(k));
					}
					tmpMenuList.clear();
					tmpMenuList.add(tmpList.get(i).getOrderedMenu());
				}
				if(i == (tmpList.size()-1)) {
					int sumPrice = 0;
					for(Map.Entry<Integer, Integer> item : totalPriceList.entrySet()) {
						if(item.getKey() == tmpList.get(i).getOrderedStatusId()) {
							sumPrice = item.getValue();
						}
					}
					ArrayList<String> cloneMenu = new ArrayList<String>();
					cloneMenu.addAll(tmpMenuList);
					OrderHistoryVO vo = new OrderHistoryVO(tmpList.get(i-1).getOrderedResName(), cloneMenu, tmpList.get(i-1).getOrderedDate(), sumPrice);
					orderHistoryList.add(vo);
					for(int k=0; k<tmpMenuList.size(); k++) {
						System.out.println("---> tmpMenuList 메뉴: " + cloneMenu.get(k));
					}
					tmpMenuList.clear();
				}
			}
			
			rs2.close();
			pstmt2.close();
			rs.close();
			pstmt.close();
			conn.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return orderHistoryList;
	}

	@Override
	public boolean setCustomerAddress(String customerId, String address) {
		String sql = "update customer set address = ? where customer_id = ?";
		boolean result = false;
		try {
			Connection conn = dataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, address);
			pstmt.setString(2, customerId);
			if(pstmt.executeUpdate() >= 1){
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
