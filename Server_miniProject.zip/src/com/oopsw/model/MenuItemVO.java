package com.oopsw.model;

public class MenuItemVO {
	private String menuId;
	private String menuName;
	private String menuPrice;
	
	public MenuItemVO(String menuId, String menuName, String menuPrice) {
		setMenuId(menuId);
		setMenuName(menuName);
		setMenuPrice(menuPrice);
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public String getMenuPrice() {
		return menuPrice;
	}

	public void setMenuPrice(String menuPrice) {
		this.menuPrice = menuPrice;
	}

	@Override
	public String toString() {
		return "MenuItemVO [menuId=" + menuId + ", menuName=" + menuName + ", menuPrice=" + menuPrice + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((menuId == null) ? 0 : menuId.hashCode());
		result = prime * result + ((menuName == null) ? 0 : menuName.hashCode());
		result = prime * result + ((menuPrice == null) ? 0 : menuPrice.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MenuItemVO other = (MenuItemVO) obj;
		if (menuId == null) {
			if (other.menuId != null)
				return false;
		} else if (!menuId.equals(other.menuId))
			return false;
		if (menuName == null) {
			if (other.menuName != null)
				return false;
		} else if (!menuName.equals(other.menuName))
			return false;
		if (menuPrice == null) {
			if (other.menuPrice != null)
				return false;
		} else if (!menuPrice.equals(other.menuPrice))
			return false;
		return true;
	}
	
	

}
