package com.oopsw.model;

import java.sql.Date;
import java.util.ArrayList;

public class OrderHistoryVO {
	private String orderedResName;
	private String orderedMenu;
	private int orderedServings;
	private int orderedStatusId;
	private Date orderedDate;
	private String deliveryDone;
	private ArrayList<String> orderedMenuList;
	private int totalPrice;
	
	public OrderHistoryVO(String orderedResName, String orderedMenu, int orderedServings, int orderedStatusId,
			Date orderedDate, String deliveryDone) {
		setOrderedResName(orderedResName);
		setOrderedMenu(orderedMenu);
		setOrderedServings(orderedServings);
		setOrderedStatusId(orderedStatusId);
		setOrderedDate(orderedDate);
		setDeliveryDone(deliveryDone);
	}
	
	// 주문 내역 조회 출력용 생성자
	public OrderHistoryVO(String orderedResName, ArrayList orderedMenuList, Date orderedDate, int totalPrice) {
		setOrderedResName(orderedResName);
		setOrderedMenuList(orderedMenuList);
		setOrderedDate(orderedDate);
		setTotalPrice(totalPrice);
	}
	
	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	public ArrayList<String> getOrderedMenuList() {
		return orderedMenuList;
	}

	public void setOrderedMenuList(ArrayList<String> orderedMenuList) {
		this.orderedMenuList = orderedMenuList;
	}

	public String getOrderedResName() {
		return orderedResName;
	}
	public void setOrderedResName(String orderedResName) {
		this.orderedResName = orderedResName;
	}
	public String getOrderedMenu() {
		return orderedMenu;
	}
	public void setOrderedMenu(String orderedMenu) {
		this.orderedMenu = orderedMenu;
	}
	public int getOrderedServings() {
		return orderedServings;
	}
	public void setOrderedServings(int orderedServings) {
		this.orderedServings = orderedServings;
	}
	public int getOrderedStatusId() {
		return orderedStatusId;
	}
	public void setOrderedStatusId(int orderedStatusId) {
		this.orderedStatusId = orderedStatusId;
	}
	public Date getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(Date orderedDate) {
		this.orderedDate = orderedDate;
	}
	public String getDeliveryDone() {
		return deliveryDone;
	}
	public void setDeliveryDone(String deliveryDone) {
		this.deliveryDone = deliveryDone;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderedMenu == null) ? 0 : orderedMenu.hashCode());
		result = prime * result + ((orderedResName == null) ? 0 : orderedResName.hashCode());
		result = prime * result + orderedServings;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderHistoryVO other = (OrderHistoryVO) obj;
		if (orderedMenu == null) {
			if (other.orderedMenu != null)
				return false;
		} else if (!orderedMenu.equals(other.orderedMenu))
			return false;
		if (orderedResName == null) {
			if (other.orderedResName != null)
				return false;
		} else if (!orderedResName.equals(other.orderedResName))
			return false;
		if (orderedServings != other.orderedServings)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OrderHistoryVO [orderedResName=" + orderedResName + ", orderedMenu=" + orderedMenu
				+ ", orderedServings=" + orderedServings + "]";
	}
	
	
}
