package com.oopsw.model;

public class MenuVO {
	private int menuId;
	private String restaurantId;
	private String name;
	private int price;
	private String category;
	private char discontinued;
	
	
}
