package com.oopsw.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.oopsw.model.JoinUserDAO;

public class ChkDuplicateIdAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int result = 0;
		String id = request.getParameter("userId");
		JoinUserDAO dao = new JoinUserDAO();
		if(dao.checkDuplicateId(id) == 0) {
			result = 0;
		} else {
			result = 1;
		}
		
		request.setAttribute("result", result);
		return "id_result.jsp";
	}

}
