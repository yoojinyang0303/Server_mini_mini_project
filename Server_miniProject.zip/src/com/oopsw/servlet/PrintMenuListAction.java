package com.oopsw.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.oopsw.model.CustomerDAO;

public class PrintMenuListAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		String resId = request.getParameter("resId");
		String resName = request.getParameter("resName");
		String searchKeyword = request.getParameter("searchKeyword");
		String url = "viewerMenuList.jsp";
		try {
			CustomerDAO dao = new CustomerDAO();
			ArrayList menuList = dao.printMenuList(resId);
			
			request.setAttribute("resId", resId);
			request.setAttribute("searchKeyword", searchKeyword);
			request.setAttribute("resName", resName);
			request.setAttribute("menuList", menuList);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return url;
	}

}
