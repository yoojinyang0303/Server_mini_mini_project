package com.oopsw.servlet;

public class ActionFactory {

	public static Action getAction(String cmd) {
		Action a = null;
		switch(cmd) {
		case "loginUI":
			a = new LoginUI();
			break;
		case "loginAction":
			a = new LoginAction();
			break;
		case "logoutAction":
			a = new LogoutAction();
			break;
		case "joinUserUI":
			a = new JoinUserUI();
			break;
		case "joinUserAction":
			a = new JoinUserAction();
			break;
		case "chkDuplicateIdAction":
			a = new ChkDuplicateIdAction();
			break;
		case "searchListUI":
			a = new SearchListUI();
			break;
		case "searchListAction":
			a = new SearchListAction();
			break;
		case "printMenuListAction":
			a = new PrintMenuListAction();
			break;
		case "addOrderListAction":
			a = new AddOrderListAction();
			break;
		case "customerOrderAction":
			a = new CustomerOrderAction();
			break;
		case "customerMainUI":
			a = new CustomerMainUI();
			break;
		case "orderHistoryAction":
			a = new OrderHistoryAction();
			break;
		case "modifyAddressUI":
			a = new ModifyAddressUI();
			break;
		case "modifyAddressAction":
			a = new ModifyAddressAction();
			break;
		}
		return a;
	}

}
