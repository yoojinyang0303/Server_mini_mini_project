package com.oopsw.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class AddOrderListAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		int result = 0;
		String orderMenu = request.getParameter("orderMenu");
		String orderServing = request.getParameter("orderServing");
		String resId = request.getParameter("resId");
		HttpSession session = request.getSession(true);
		if(session.getAttribute("orderList") != null) {
			HashMap<String, String> orderList = (HashMap)session.getAttribute("orderList");
			if(orderList.containsValue(resId)) {
				orderList.put(orderMenu, orderServing);
				result = 0;
			} else if(!orderList.containsValue(resId)) {
				System.out.println("!containsValue resId");
				result = 1;
				request.setAttribute("result", result);
				return "addOrderList_result.jsp";
			}
			session.setAttribute("orderList", orderList);
		} else {
			HashMap<String, String> orderList = new HashMap<String, String>();
			orderList.put("resId", resId);
			orderList.put(orderMenu, orderServing);
			session.setAttribute("orderList", orderList);
		}
		
		
		request.setAttribute("result", result);
		return "addOrderList_result.jsp";
	}

}
