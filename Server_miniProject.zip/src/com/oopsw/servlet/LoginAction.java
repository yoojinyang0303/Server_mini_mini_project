package com.oopsw.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.oopsw.model.LoginDAO;

public class LoginAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("inputId");
		String pw = request.getParameter("inputPW");
		// JDBC-DAO
		String url = "login.jsp";
		char userType = new LoginDAO().login(id, pw);
		
		if(userType != 0) {
			System.out.println("if userType != 0");
			HttpSession session = request.getSession(true);
			session.setAttribute("loginId", id);		
			switch(userType) {
			case '1':
				url = "controller?cmd=customerMainUI";
				break;
			case '2':
				url = "main_restaurant.jsp";
				break;
			case '3':
				url = "main_rider.jsp";
				break;
			}
		}
		
		return url;
	}

}
