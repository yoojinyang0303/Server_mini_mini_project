package com.oopsw.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.oopsw.model.CustomerDAO;
import com.oopsw.model.JoinUserDAO;

public class JoinUserAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userType = request.getParameter("userType");
		String id = request.getParameter("inputId");
		String pw = request.getParameter("inputPW");
		String address = "";
		JoinUserDAO dao = new JoinUserDAO();
		
		String url = "login.jsp";
		
		switch(userType) {
		case "1":
			address = request.getParameter("inputAddressDetail");
			dao.setUser(id, pw, address);
			break;
		case "2":
			String restaurantName = request.getParameter("restaurantName");
			String businessNumber = request.getParameter("businessNumber");
			address = request.getParameter("detailAddress");
			dao.setUser(id, pw, restaurantName, address, businessNumber);
			break;
		case "3":
			String deliveryType = request.getParameter("deliveryType");
			String deliveryLicense = request.getParameter("deliveryLicense");
			dao.setUser(id, pw, deliveryType, deliveryLicense);
			break;
		}
		
		return url;
	}

}




/*
public class JoinUserAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("joinUserAction 파일");
		String userType = request.getParameter("userType");
		System.out.println("click UserType: " + userType);
		String id = request.getParameter("inputId");
		String pw = request.getParameter("inputPW");
		String address = "";
		JoinUserDAO dao = new JoinUserDAO();
		if(dao.checkDuplicateId(id) != 0) {
			
		}
		
		String url = "login.jsp";
		
		switch(userType) {
		case "1":
			address = request.getParameter("inputAddressDetail");
			dao.setUser(id, pw, address);
			System.out.println("고객 회원가입 완료");
			/*if(dao.setUser(id, pw, address) == true) {
				System.out.println("고객 회원가입 완료");
				url = "login.jsp";
			} else {
				System.out.println("고객 회원가입 실패_중복된 아이디");
				url = "?!";
			}		
			break;
		case "2":
			String restaurantName = request.getParameter("restaurantName");
			String businessNumber = request.getParameter("businessNumber");
			address = request.getParameter("detailAddress");
			dao.setUser(id, pw, restaurantName, address, businessNumber);
			System.out.println("가게 회원가입 완료");
			break;
		case "3":
			String deliveryType = request.getParameter("deliveryType");
			String deliveryLicense = request.getParameter("deliveryLicense");
			dao.setUser(id, pw, deliveryType, deliveryLicense);
			System.out.println("라이더 회원가입 완료");
			break;
		}
		
		
		return url;
	}

}
 
 */