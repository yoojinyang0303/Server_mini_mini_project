package com.oopsw.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.oopsw.model.CustomerDAO;

public class SearchListAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		String searchId = request.getParameter("resId");
		String searchKeyword = request.getParameter("input");
		String url = "searchList.jsp";
		try {
			CustomerDAO dao = new CustomerDAO();
			HashMap<String,String> resultMap = dao.searchRestaurantOrMenu(searchKeyword);
			for(int i=0; i<resultMap.size(); i++) {
			}
			request.setAttribute("searchKeyword", searchKeyword);
			request.setAttribute("resultMap", resultMap);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return url;
	}

}
