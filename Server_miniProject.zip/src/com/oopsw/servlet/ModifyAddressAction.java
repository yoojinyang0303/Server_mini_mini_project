package com.oopsw.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.oopsw.model.CustomerDAO;

public class ModifyAddressAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String loginId = session.getAttribute("loginId").toString();
		String address = request.getParameter("address");
		String detailAddress = request.getParameter("detailAddress");
		String updateAddress = address + " " + detailAddress;
		
		try {
			CustomerDAO dao = new CustomerDAO();
			dao.setCustomerAddress(loginId, updateAddress);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "main_customer.jsp";
	}

}
