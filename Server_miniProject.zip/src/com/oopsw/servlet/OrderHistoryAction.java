package com.oopsw.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.oopsw.model.CustomerDAO;

public class OrderHistoryAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String loginId = session.getAttribute("loginId").toString();
		try {
			CustomerDAO dao = new CustomerDAO();
			ArrayList orderHistory = dao.printOrderHistory(loginId);
			
			request.setAttribute("orderHistory", orderHistory);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "orderHistory.jsp";
	}

}
