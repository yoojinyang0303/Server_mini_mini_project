package com.oopsw.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.oopsw.model.CustomerDAO;

public class CustomerOrderAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int result = 0;
		String loginId = session.getAttribute("loginId").toString();
		String resId = request.getParameter("resId");
		String orderMenu = request.getParameter("orderMenu");
		String orderServing = request.getParameter("orderServing");
		
		if(session.getAttribute("orderList") != null) {
			System.out.println("get OrderList != null");
			HashMap<String, String> orderList = (HashMap)session.getAttribute("orderList");
			if(orderList.containsValue(resId)) {
				orderList.put(orderMenu, orderServing);
				result = 0;
			} else if(!orderList.containsValue(resId)) {
				result = 1;
				request.setAttribute("result", result);
				return "addOrderList_result.jsp";
			}
			session.setAttribute("orderList", orderList);
			
			CustomerDAO dao;
			try {
				dao = new CustomerDAO();
				dao.setOrderStatus(loginId);
				for(Map.Entry<String, String> item : orderList.entrySet()) {
					if(!item.getValue().equals(resId)) {
						dao.setOrder(loginId, item.getKey(), resId, Integer.parseInt(item.getValue()));
					}
				}
			} catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		} else {
			HashMap<String, String> orderList = new HashMap<String, String>();
			orderList.put(orderMenu, orderServing);
			result = 0;
			
			request.setAttribute("result", result);
			session.setAttribute("orderList", orderList);
			
			CustomerDAO dao;
			try {
				dao = new CustomerDAO();
				dao.setOrderStatus(loginId);
				for(Map.Entry<String, String> item : orderList.entrySet()) {
					if(!item.getValue().equals(resId)) {
						dao.setOrder(loginId, item.getKey(), resId, Integer.parseInt(item.getValue()));
					}
				}
			} catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		
		// 주문 후 세션에서 orderList 데이터 제거
		HashMap<String, String> orderList = (HashMap)session.getAttribute("orderList");
		if(orderList != null) {
			session.removeAttribute("orderList");
			session.removeAttribute("resId");
		}
		String url = "main_customer.jsp";
		
		// return url;
		return "addOrderList_result.jsp";
	}

}








